# ConflictDB - Guia de Hospedagem

## Opção 1: Vercel (Recomendado - Gratuito)

### Vantagens
- Deploy automático do GitHub
- SSL gratuito
- CDN global
- Fácil configuração

### Setup
1. Faça push do código para GitHub
2. Conecte sua conta Vercel ao GitHub
3. Import o projeto no Vercel
4. Configure as variáveis de ambiente:
   ```
   DATABASE_URL=sua_string_conexao_postgresql
   ```
5. Deploy automático!

**URL final**: `https://seu-projeto.vercel.app`

## Opção 2: Railway (Banco + App)

### Vantagens
- PostgreSQL incluído
- Deploy simples
- Preço acessível

### Setup
1. Crie conta no Railway
2. Deploy from GitHub
3. Adicione PostgreSQL service
4. Conecte as variáveis automaticamente
5. Deploy!

## Opção 3: Render (Gratuito com limitações)

### Vantagens
- Tier gratuito
- PostgreSQL gratuito (limitado)
- SSL incluído

### Setup
1. Conecte GitHub ao Render
2. Create Web Service
3. Create PostgreSQL database
4. Configure environment variables
5. Deploy

## Opção 4: DigitalOcean App Platform

### Vantagens
- Controle total
- Droplets econômicos
- Managed databases

### Setup
1. Create App from GitHub
2. Add managed PostgreSQL
3. Configure environment
4. Deploy

## Opção 5: AWS (Avançado)

### Componentes
- **Frontend**: S3 + CloudFront
- **Backend**: EC2 ou ECS
- **Database**: RDS PostgreSQL
- **Load Balancer**: ALB

## Configuração de Produção

### Variáveis de Ambiente Necessárias
```bash
DATABASE_URL=postgresql://user:pass@host:5432/dbname
NODE_ENV=production
PORT=5000
```

### Build para Produção
```bash
# Build frontend
npm run build

# Start production server
npm start
```

## Compartilhamento Simples

### Opção Rápida: Replit Share
- Clique em "Share" no Replit
- Copie o link público
- Qualquer pessoa pode acessar

### Opção Profissional: Domínio Personalizado
1. Registre um domínio (.com, .org, etc.)
2. Configure DNS para apontar para seu host
3. Configure SSL certificado
4. Exemplo: `https://conflictdb.seudominio.com`

## Monitoramento e Manutenção

### Logs e Erros
- Configure alertas de erro
- Monitor de uptime
- Backup automático do banco

### Performance
- Configure cache
- Otimize queries SQL
- Monitor uso de recursos

## Custos Estimados

| Serviço | Tier Gratuito | Paid Plan |
|---------|---------------|-----------|
| Vercel | Sim (hobby) | $20/mês |
| Railway | $5 crédito | $5+/mês |
| Render | 750h grátis | $7+/mês |
| AWS | 12 meses free | $10+/mês |

**Recomendação**: Comece com Vercel (gratuito) + banco PostgreSQL gratuito (PlanetScale, Neon, ou Supabase).