# ConflictDB - Setup Local

## Pré-requisitos
- Node.js 18+ instalado
- PostgreSQL instalado e rodando
- Git (opcional)

## Instalação

### 1. Baixar o projeto
- Download do Replit como ZIP, ou
- Clone: `git clone [URL_DO_SEU_REPLIT]`

### 2. Instalar dependências
```bash
cd conflictdb
npm install
```

### 3. Configurar PostgreSQL
Crie um banco de dados PostgreSQL e configure as variáveis de ambiente:

```bash
# Crie o arquivo .env na raiz do projeto
DATABASE_URL=postgresql://usuario:senha@localhost:5432/conflictdb
PGHOST=localhost
PGPORT=5432
PGDATABASE=conflictdb
PGUSER=seu_usuario
PGPASSWORD=sua_senha
```

### 4. Criar e popular o banco
```bash
# Aplicar schema ao banco
npm run db:push

# Popular com dados iniciais (executar os SQLs da pasta attached_assets)
# Ou usar a interface administrativa para inserir dados
```

### 5. Executar a aplicação
```bash
npm run dev
```

Acesse: http://localhost:5000

## Estrutura do Projeto
```
conflictdb/
├── client/          # Frontend React
├── server/          # Backend Express
├── shared/          # Schemas compartilhados
├── attached_assets/ # Scripts SQL iniciais
└── package.json
```

## Dependências Principais
- Frontend: React, Vite, TailwindCSS, Monaco Editor, Recharts
- Backend: Express, Drizzle ORM, PostgreSQL
- Database: PostgreSQL com Neon driver