import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import DatabaseInterface from "@/pages/database-interface";
import AdminPanel from "@/pages/admin-panel";

function Router() {
  const [location] = useLocation();
  
  return (
    <div className="min-h-screen bg-db-dark">
      {/* Navigation */}
      <nav className="bg-db-panel border-b border-db-border p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <i className="fas fa-database text-db-accent text-2xl"></i>
            <h1 className="text-xl font-bold text-db-text">ConflictDB Manager</h1>
          </div>
          <div className="flex space-x-4">
            <Link href="/">
              <span className={`px-4 py-2 rounded transition-colors cursor-pointer ${
                location === "/" 
                  ? "bg-db-accent text-white" 
                  : "text-db-text-muted hover:text-db-text hover:bg-db-hover"
              }`}>
                <i className="fas fa-code mr-2"></i>Query Interface
              </span>
            </Link>
            <Link href="/admin">
              <span className={`px-4 py-2 rounded transition-colors cursor-pointer ${
                location === "/admin" 
                  ? "bg-db-accent text-white" 
                  : "text-db-text-muted hover:text-db-text hover:bg-db-hover"
              }`}>
                <i className="fas fa-cogs mr-2"></i>Painel Administrativo
              </span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Routes */}
      <Switch>
        <Route path="/" component={DatabaseInterface} />
        <Route path="/admin" component={AdminPanel} />
        <Route>
          <div className="min-h-screen flex items-center justify-center bg-db-dark">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-db-text mb-4">Page Not Found</h1>
              <p className="text-db-text-muted">The requested page could not be found.</p>
            </div>
          </div>
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
