import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import SchemaBrowser from "@/components/schema-browser";
import QueryEditor from "@/components/query-editor";
import QueryResults from "@/components/query-results";
import QueryManager from "@/components/query-manager";

interface DatabaseSchema {
  tables: Array<{
    name: string;
    columns: Array<{
      name: string;
      type: string;
      nullable: boolean;
      default?: string;
    }>;
    rowCount: number;
  }>;
}

export default function DatabaseInterface() {
  const [currentQuery, setCurrentQuery] = useState(`-- Sample Query: Group Strength Analysis
SELECT 
    ga.nome AS grupo_nome,
    COUNT(d.numero_divisao) AS total_divisoes,
    SUM(d.numero_homens) AS total_homens,
    SUM(d.numero_baixas) AS total_baixas,
    ROUND((SUM(d.numero_baixas)::decimal / NULLIF(SUM(d.numero_homens), 0) * 100), 2) AS taxa_baixas_percent
FROM grupo_armado ga
LEFT JOIN divisao d ON ga.id = d.id_grupo_armado
GROUP BY ga.id, ga.nome
ORDER BY total_baixas DESC;`);

  const [queryResults, setQueryResults] = useState<any>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionTime, setExecutionTime] = useState<number | null>(null);

  const { data: schema, isLoading: schemaLoading } = useQuery<DatabaseSchema>({
    queryKey: ["/api/schema"],
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  const executeQuery = async () => {
    if (!currentQuery.trim()) return;
    
    setIsExecuting(true);
    try {
      const response = await fetch("/api/query/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: currentQuery }),
        credentials: "include",
      });
      
      const result = await response.json();
      setQueryResults(result);
      setExecutionTime(result.executionTime);
    } catch (error) {
      setQueryResults({
        success: false,
        error: error instanceof Error ? error.message : "Failed to execute query",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      executeQuery();
    }
  };

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [currentQuery]);

  return (
    <div className="h-screen bg-db-dark text-db-text font-interface flex flex-col">
      {/* Header */}
      <header className="bg-db-panel border-b border-db-border shadow-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <i className="fas fa-database text-db-accent text-2xl"></i>
            <div>
              <h1 className="text-xl font-bold text-db-text">ConflictDB Manager</h1>
              <p className="text-sm text-db-text-muted">PostgreSQL Query Interface</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-db-dark px-3 py-2 rounded-lg">
              <div className="w-2 h-2 bg-db-success rounded-full animate-pulse"></div>
              <span className="text-sm text-db-text-muted">Connected to ConflictDB</span>
            </div>
            <button className="bg-db-accent hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors duration-200">
              <i className="fas fa-cog mr-2"></i>Settings
            </button>
          </div>
        </div>
      </header>

      {/* Main Interface */}
      <div className="flex-1 flex min-h-0">
        {/* Schema Browser */}
        <div className="w-80 bg-db-panel border-r border-db-border">
          <SchemaBrowser 
            schema={schema} 
            isLoading={schemaLoading}
            onTableSelect={(tableName) => {
              setCurrentQuery(`SELECT * FROM ${tableName} LIMIT 10;`);
            }}
          />
        </div>

        {/* Main Workspace */}
        <div className="flex-1 flex flex-col">
          {/* Query Toolbar */}
          <div className="bg-db-panel border-b border-db-border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h2 className="text-lg font-semibold text-db-text">Query Editor</h2>
                <div className="flex items-center space-x-2">
                  <button className="bg-db-dark hover:bg-db-hover text-db-text-muted px-3 py-2 rounded-lg text-sm transition-colors duration-200">
                    <i className="fas fa-plus mr-2"></i>New Query
                  </button>
                  <button className="bg-db-dark hover:bg-db-hover text-db-text-muted px-3 py-2 rounded-lg text-sm transition-colors duration-200">
                    <i className="fas fa-folder-open mr-2"></i>Load Query
                  </button>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={executeQuery}
                  disabled={isExecuting}
                  className="bg-db-success hover:bg-green-600 text-white px-6 py-2 rounded-lg font-medium transition-colors duration-200 disabled:opacity-50"
                >
                  {isExecuting ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>Executing...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-play mr-2"></i>Execute Query
                    </>
                  )}
                </button>
                {executionTime && (
                  <span className="text-sm text-db-text-muted">
                    {executionTime}ms
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Query Templates Bar */}
          <div className="bg-db-dark border-b border-db-border p-3">
            <div className="flex items-center space-x-2 overflow-x-auto">
              <span className="text-sm text-db-text-muted whitespace-nowrap">Quick Templates:</span>
              {templates?.map((template: any, index: number) => (
                <button
                  key={index}
                  onClick={() => setCurrentQuery(template.query)}
                  className="bg-db-border hover:bg-db-hover text-db-text-muted px-3 py-1 rounded text-sm whitespace-nowrap transition-colors duration-200"
                >
                  {template.name}
                </button>
              ))}
            </div>
          </div>

          {/* Query Editor */}
          <QueryEditor 
            value={currentQuery}
            onChange={setCurrentQuery}
            onExecute={executeQuery}
          />

          {/* Query Results */}
          <QueryResults 
            results={queryResults}
            isLoading={isExecuting}
          />
        </div>

        {/* Query Manager */}
        <div className="w-80 bg-db-panel border-l border-db-border">
          <QueryManager 
            onQuerySelect={setCurrentQuery}
            currentQuery={currentQuery}
          />
        </div>
      </div>
    </div>
  );
}
