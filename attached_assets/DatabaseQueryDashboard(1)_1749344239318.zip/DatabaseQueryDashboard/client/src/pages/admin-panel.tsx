import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function AdminPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form states for data entry
  const [conflictForm, setConflictForm] = useState({
    id: '', nome: '', lugar: '', causa: '', totalMortos: '', totalFeridos: ''
  });
  
  const [groupForm, setGroupForm] = useState({
    id: '', nome: '', numeroBaixas: ''
  });

  const [divisionForm, setDivisionForm] = useState({
    numeroDivisao: '', idGrupoArmado: '', numeroBarcos: '', numeroTanques: '', 
    numeroAvioes: '', numeroHomens: '', numeroBaixas: ''
  });

  const [leaderForm, setLeaderForm] = useState({
    nome: '', idGrupoArmado: '', apoio: ''
  });

  const [militaryChiefForm, setMilitaryChiefForm] = useState({
    id: '', faixaHierarquica: '', nomeLiderPolitico: '', idGrupoArmado: '', numeroDivisao: ''
  });

  // Query results states
  const [conflictChart, setConflictChart] = useState<any[]>([]);
  const [barretTraffickers, setBarretTraffickers] = useState<any[]>([]);
  const [topConflicts, setTopConflicts] = useState<any[]>([]);
  const [topOrganizations, setTopOrganizations] = useState<any[]>([]);
  const [topArmedGroups, setTopArmedGroups] = useState<any[]>([]);
  const [religiousConflicts, setReligiousConflicts] = useState<any[]>([]);

  // Mutation for inserting data
  const insertMutation = useMutation({
    mutationFn: async ({ query }: { query: string }) => {
      const response = await fetch("/api/query/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schema"] });
      toast({
        title: "Sucesso",
        description: "Dados inseridos com sucesso!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao inserir dados",
        variant: "destructive",
      });
    },
  });

  // Query execution for reports
  const executeQuery = async (query: string, setter: Function) => {
    try {
      const response = await fetch("/api/query/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      const result = await response.json();
      if (result.success) {
        setter(result.data);
      } else {
        toast({
          title: "Erro na consulta",
          description: result.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao executar consulta",
        variant: "destructive",
      });
    }
  };

  const handleConflictSubmit = () => {
    const query = `INSERT INTO conflito (id, nome, lugar, causa, total_mortos, total_feridos) 
                   VALUES ('${conflictForm.id}', '${conflictForm.nome}', '${conflictForm.lugar}', 
                          '${conflictForm.causa}', ${conflictForm.totalMortos}, ${conflictForm.totalFeridos})`;
    insertMutation.mutate({ query });
    setConflictForm({ id: '', nome: '', lugar: '', causa: '', totalMortos: '', totalFeridos: '' });
  };

  const handleGroupSubmit = () => {
    const query = `INSERT INTO grupo_armado (id, nome, numero_baixas) 
                   VALUES ('${groupForm.id}', '${groupForm.nome}', ${groupForm.numeroBaixas})`;
    insertMutation.mutate({ query });
    setGroupForm({ id: '', nome: '', numeroBaixas: '' });
  };

  const handleDivisionSubmit = () => {
    const query = `INSERT INTO divisao (numero_divisao, id_grupo_armado, numero_barcos, numero_tanques, numero_avioes, numero_homens, numero_baixas) 
                   VALUES ('${divisionForm.numeroDivisao}', '${divisionForm.idGrupoArmado}', ${divisionForm.numeroBarcos}, 
                          ${divisionForm.numeroTanques}, ${divisionForm.numeroAvioes}, ${divisionForm.numeroHomens}, ${divisionForm.numeroBaixas})`;
    insertMutation.mutate({ query });
    setDivisionForm({ numeroDivisao: '', idGrupoArmado: '', numeroBarcos: '', numeroTanques: '', numeroAvioes: '', numeroHomens: '', numeroBaixas: '' });
  };

  const handleLeaderSubmit = () => {
    const query = `INSERT INTO lider_politico (nome, id_grupo_armado, apoio) 
                   VALUES ('${leaderForm.nome}', '${leaderForm.idGrupoArmado}', '${leaderForm.apoio}')`;
    insertMutation.mutate({ query });
    setLeaderForm({ nome: '', idGrupoArmado: '', apoio: '' });
  };

  const handleMilitaryChiefSubmit = () => {
    const query = `INSERT INTO chefe_militar (id, faixa_hierarquica, nome_lider_politico, id_grupo_armado, numero_divisao) 
                   VALUES ('${militaryChiefForm.id}', '${militaryChiefForm.faixaHierarquica}', '${militaryChiefForm.nomeLiderPolitico}', '${militaryChiefForm.idGrupoArmado}', '${militaryChiefForm.numeroDivisao}')`;
    insertMutation.mutate({ query });
    setMilitaryChiefForm({ id: '', faixaHierarquica: '', nomeLiderPolitico: '', idGrupoArmado: '', numeroDivisao: '' });
  };

  // Report queries
  const generateConflictChart = () => {
    const query = `SELECT causa as tipo_conflito, COUNT(*) as numero_conflitos 
                   FROM conflito GROUP BY causa ORDER BY numero_conflitos DESC`;
    executeQuery(query, setConflictChart);
  };

  const findBarretTraffickers = () => {
    const query = `SELECT DISTINCT t.nome as traficante, ga.nome as grupo_armado
                   FROM traficantes t
                   JOIN fornecimento f ON t.nome = f.nome_traficante
                   JOIN grupo_armado ga ON f.id_grupo_armado = ga.id
                   WHERE f.nome_arma IN ('Barret M82', 'M200 Intervent.')
                   ORDER BY t.nome, ga.nome`;
    executeQuery(query, setBarretTraffickers);
  };

  const getTopConflicts = () => {
    const query = `SELECT nome, lugar, total_mortos, total_feridos
                   FROM conflito ORDER BY total_mortos DESC LIMIT 5`;
    executeQuery(query, setTopConflicts);
  };

  const getTopOrganizations = () => {
    const query = `SELECT om.nome, COUNT(*) as mediacao_count
                   FROM org_mediadora om
                   JOIN participacao_org_mediadora pom ON om.id = pom.id_org_mediadora
                   GROUP BY om.id, om.nome
                   ORDER BY mediacao_count DESC LIMIT 5`;
    executeQuery(query, setTopOrganizations);
  };

  const getTopArmedGroups = () => {
    const query = `SELECT ga.nome, COUNT(f.nome_arma) as armas_fornecidas
                   FROM grupo_armado ga
                   LEFT JOIN fornecimento f ON ga.id = f.id_grupo_armado
                   GROUP BY ga.id, ga.nome
                   ORDER BY armas_fornecidas DESC LIMIT 5`;
    executeQuery(query, setTopArmedGroups);
  };

  const getReligiousConflicts = () => {
    const query = `SELECT pec.pais_envolvido, COUNT(*) as conflitos_religiosos
                   FROM paises_em_conflito pec
                   JOIN conflito c ON pec.id_conflito = c.id
                   WHERE c.causa = 'religioso'
                   GROUP BY pec.pais_envolvido
                   ORDER BY conflitos_religiosos DESC`;
    executeQuery(query, setReligiousConflicts);
  };

  return (
    <div className="min-h-screen bg-db-dark text-db-text p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-db-accent">ConflictDB - Painel Administrativo</h1>
        
        <Tabs defaultValue="cadastro" className="w-full">
          <TabsList className="grid grid-cols-2 w-full max-w-md bg-db-panel">
            <TabsTrigger value="cadastro" className="text-db-text">Cadastro de Dados</TabsTrigger>
            <TabsTrigger value="relatorios" className="text-db-text">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="cadastro" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Cadastro de Conflitos */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Cadastrar Conflito</CardTitle>
                  <CardDescription className="text-db-text-muted">Adicionar novo conflito bélico</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>ID</Label>
                      <Input 
                        value={conflictForm.id} 
                        onChange={(e) => setConflictForm({...conflictForm, id: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Nome</Label>
                      <Input 
                        value={conflictForm.nome} 
                        onChange={(e) => setConflictForm({...conflictForm, nome: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Lugar</Label>
                      <Input 
                        value={conflictForm.lugar} 
                        onChange={(e) => setConflictForm({...conflictForm, lugar: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Causa</Label>
                      <Input 
                        value={conflictForm.causa} 
                        onChange={(e) => setConflictForm({...conflictForm, causa: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Total Mortos</Label>
                      <Input 
                        type="number"
                        value={conflictForm.totalMortos} 
                        onChange={(e) => setConflictForm({...conflictForm, totalMortos: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Total Feridos</Label>
                      <Input 
                        type="number"
                        value={conflictForm.totalFeridos} 
                        onChange={(e) => setConflictForm({...conflictForm, totalFeridos: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <Button onClick={handleConflictSubmit} className="w-full bg-db-accent hover:bg-red-600">
                    Cadastrar Conflito
                  </Button>
                </CardContent>
              </Card>

              {/* Cadastro de Grupos Armados */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Cadastrar Grupo Armado</CardTitle>
                  <CardDescription className="text-db-text-muted">Adicionar novo grupo militar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>ID</Label>
                      <Input 
                        value={groupForm.id} 
                        onChange={(e) => setGroupForm({...groupForm, id: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Nome</Label>
                      <Input 
                        value={groupForm.nome} 
                        onChange={(e) => setGroupForm({...groupForm, nome: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Número de Baixas</Label>
                    <Input 
                      type="number"
                      value={groupForm.numeroBaixas} 
                      onChange={(e) => setGroupForm({...groupForm, numeroBaixas: e.target.value})}
                      className="bg-db-dark border-db-border text-db-text"
                    />
                  </div>
                  <Button onClick={handleGroupSubmit} className="w-full bg-db-accent hover:bg-red-600">
                    Cadastrar Grupo
                  </Button>
                </CardContent>
              </Card>

              {/* Cadastro de Divisões */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Cadastrar Divisão</CardTitle>
                  <CardDescription className="text-db-text-muted">Adicionar divisão militar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Número da Divisão</Label>
                      <Input 
                        value={divisionForm.numeroDivisao} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroDivisao: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>ID Grupo Armado</Label>
                      <Input 
                        value={divisionForm.idGrupoArmado} 
                        onChange={(e) => setDivisionForm({...divisionForm, idGrupoArmado: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>Barcos</Label>
                      <Input 
                        type="number"
                        value={divisionForm.numeroBarcos} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroBarcos: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Tanques</Label>
                      <Input 
                        type="number"
                        value={divisionForm.numeroTanques} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroTanques: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Aviões</Label>
                      <Input 
                        type="number"
                        value={divisionForm.numeroAvioes} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroAvioes: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Homens</Label>
                      <Input 
                        type="number"
                        value={divisionForm.numeroHomens} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroHomens: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                    <div>
                      <Label>Baixas</Label>
                      <Input 
                        type="number"
                        value={divisionForm.numeroBaixas} 
                        onChange={(e) => setDivisionForm({...divisionForm, numeroBaixas: e.target.value})}
                        className="bg-db-dark border-db-border text-db-text"
                      />
                    </div>
                  </div>
                  <Button onClick={handleDivisionSubmit} className="w-full bg-db-accent hover:bg-red-600">
                    Cadastrar Divisão
                  </Button>
                </CardContent>
              </Card>

              {/* Cadastro de Líderes Políticos */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Cadastrar Líder Político</CardTitle>
                  <CardDescription className="text-db-text-muted">Adicionar líder político</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Nome</Label>
                    <Input 
                      value={leaderForm.nome} 
                      onChange={(e) => setLeaderForm({...leaderForm, nome: e.target.value})}
                      className="bg-db-dark border-db-border text-db-text"
                    />
                  </div>
                  <div>
                    <Label>ID Grupo Armado</Label>
                    <Input 
                      value={leaderForm.idGrupoArmado} 
                      onChange={(e) => setLeaderForm({...leaderForm, idGrupoArmado: e.target.value})}
                      className="bg-db-dark border-db-border text-db-text"
                    />
                  </div>
                  <div>
                    <Label>Apoio</Label>
                    <Input 
                      value={leaderForm.apoio} 
                      onChange={(e) => setLeaderForm({...leaderForm, apoio: e.target.value})}
                      className="bg-db-dark border-db-border text-db-text"
                    />
                  </div>
                  <Button onClick={handleLeaderSubmit} className="w-full bg-db-accent hover:bg-red-600">
                    Cadastrar Líder
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="relatorios" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {/* Relatório 1: Gráfico por tipo de conflito */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Conflitos por Tipo</CardTitle>
                  <CardDescription className="text-db-text-muted">Histograma de conflitos por causa</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={generateConflictChart} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Gerar Gráfico
                  </Button>
                  {conflictChart.length > 0 && (
                    <div className="w-full h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={conflictChart} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis 
                            dataKey="tipo_conflito" 
                            tick={{ fill: '#9CA3AF', fontSize: 10 }}
                            angle={-45}
                            textAnchor="end"
                            height={60}
                          />
                          <YAxis tick={{ fill: '#9CA3AF' }} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '6px',
                              color: '#F9FAFB'
                            }}
                          />
                          <Bar 
                            dataKey="numero_conflitos" 
                            fill="#DC2626" 
                            name="Número de Conflitos"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Relatório 2: Traficantes Barret M82 */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Traficantes Barret/M200</CardTitle>
                  <CardDescription className="text-db-text-muted">Fornecedores de armas específicas</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={findBarretTraffickers} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Buscar Traficantes
                  </Button>
                  {barretTraffickers.length > 0 && (
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {barretTraffickers.map((item: any, index: number) => (
                        <div key={index} className="text-sm">
                          <span className="text-db-text">{item.traficante}</span>
                          <span className="text-db-text-muted"> → {item.grupo_armado}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Relatório 3: Top 5 Conflitos */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Top 5 Conflitos</CardTitle>
                  <CardDescription className="text-db-text-muted">Maiores em número de mortos</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={getTopConflicts} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Listar Conflitos
                  </Button>
                  {topConflicts.length > 0 && (
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {topConflicts.map((item: any, index: number) => (
                        <div key={index} className="text-sm">
                          <div className="text-db-text font-medium">{item.nome}</div>
                          <div className="text-db-text-muted">{item.lugar} - {item.total_mortos.toLocaleString()} mortos</div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Relatório 4: Top 5 Organizações */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Top 5 Organizações</CardTitle>
                  <CardDescription className="text-db-text-muted">Maior número de mediações</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={getTopOrganizations} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Listar Organizações
                  </Button>
                  {topOrganizations.length > 0 && (
                    <div className="space-y-2">
                      {topOrganizations.map((item: any, index: number) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-db-text">{item.nome}</span>
                          <span className="text-db-accent font-bold">{item.mediacao_count}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Relatório 5: Top 5 Grupos Armados */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Top 5 Grupos Armados</CardTitle>
                  <CardDescription className="text-db-text-muted">Maior número de armas</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={getTopArmedGroups} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Listar Grupos
                  </Button>
                  {topArmedGroups.length > 0 && (
                    <div className="space-y-2">
                      {topArmedGroups.map((item: any, index: number) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-db-text">{item.nome}</span>
                          <span className="text-db-accent font-bold">{item.armas_fornecidas}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Relatório 6: Conflitos Religiosos por País */}
              <Card className="bg-db-panel border-db-border">
                <CardHeader>
                  <CardTitle className="text-db-text">Conflitos Religiosos</CardTitle>
                  <CardDescription className="text-db-text-muted">Por país</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={getReligiousConflicts} className="w-full mb-4 bg-db-success hover:bg-green-600">
                    Buscar Conflitos
                  </Button>
                  {religiousConflicts.length > 0 && (
                    <div className="space-y-2">
                      {religiousConflicts.map((item: any, index: number) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-db-text">{item.pais_envolvido}</span>
                          <span className="text-db-accent font-bold">{item.conflitos_religiosos}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}