import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface QueryManagerProps {
  onQuerySelect: (query: string) => void;
  currentQuery: string;
}

interface SavedQuery {
  id: number;
  name: string;
  description?: string;
  query: string;
  isFavorite: number;
  createdAt: string;
  executionTime?: number;
}

interface QueryHistoryItem {
  id: number;
  query: string;
  executionTime: number;
  rowsReturned?: number;
  executedAt: string;
  success: number;
  errorMessage?: string;
}

export default function QueryManager({ onQuerySelect, currentQuery }: QueryManagerProps) {
  const [activeTab, setActiveTab] = useState<"saved" | "templates" | "history">("saved");
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [queryName, setQueryName] = useState("");
  const [queryDescription, setQueryDescription] = useState("");
  const [markFavorite, setMarkFavorite] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: savedQueries, isLoading: savedLoading } = useQuery<SavedQuery[]>({
    queryKey: ["/api/queries"],
  });

  const { data: queryHistory, isLoading: historyLoading } = useQuery<QueryHistoryItem[]>({
    queryKey: ["/api/history"],
  });

  const { data: templates } = useQuery({
    queryKey: ["/api/templates"],
  });

  const saveQueryMutation = useMutation({
    mutationFn: async (queryData: { name: string; description?: string; query: string; isFavorite: number }) => {
      return apiRequest("POST", "/api/queries", queryData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queries"] });
      setShowSaveDialog(false);
      setQueryName("");
      setQueryDescription("");
      setMarkFavorite(false);
      toast({
        title: "Query Saved",
        description: "Your query has been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteQueryMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/queries/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queries"] });
      toast({
        title: "Query Deleted",
        description: "The query has been deleted successfully.",
      });
    },
  });

  const handleSaveQuery = async () => {
    if (!queryName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a query name.",
        variant: "destructive",
      });
      return;
    }

    if (!currentQuery.trim()) {
      toast({
        title: "Error",
        description: "No query to save.",
        variant: "destructive",
      });
      return;
    }

    saveQueryMutation.mutate({
      name: queryName,
      description: queryDescription || undefined,
      query: currentQuery,
      isFavorite: markFavorite ? 1 : 0,
    });
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const truncateQuery = (query: string, maxLength = 80) => {
    if (query.length <= maxLength) return query;
    return query.substring(0, maxLength) + "...";
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-db-border">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-db-text">Query Manager</h2>
          <button
            onClick={() => setShowSaveDialog(true)}
            className="text-db-text-muted hover:text-db-text transition-colors"
          >
            <i className="fas fa-plus text-sm"></i>
          </button>
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab("saved")}
            className={`flex-1 px-3 py-2 rounded text-sm transition-colors ${
              activeTab === "saved" 
                ? "bg-db-dark text-db-text border border-db-border" 
                : "bg-db-border hover:bg-db-hover text-db-text-muted"
            }`}
          >
            Saved
          </button>
          <button
            onClick={() => setActiveTab("templates")}
            className={`flex-1 px-3 py-2 rounded text-sm transition-colors ${
              activeTab === "templates" 
                ? "bg-db-dark text-db-text border border-db-border" 
                : "bg-db-border hover:bg-db-hover text-db-text-muted"
            }`}
          >
            Templates
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`flex-1 px-3 py-2 rounded text-sm transition-colors ${
              activeTab === "history" 
                ? "bg-db-dark text-db-text border border-db-border" 
                : "bg-db-border hover:bg-db-hover text-db-text-muted"
            }`}
          >
            History
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scrollbar-thin p-2">
        {activeTab === "saved" && (
          <div className="space-y-2">
            {savedLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse bg-db-dark h-20 rounded border border-db-border"></div>
                ))}
              </div>
            ) : savedQueries && savedQueries.length > 0 ? (
              savedQueries.map((query) => (
                <div
                  key={query.id}
                  className="bg-db-dark hover:bg-db-hover rounded border border-db-border transition-colors cursor-pointer p-3"
                  onClick={() => onQuerySelect(query.query)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-2">
                      {query.isFavorite ? (
                        <i className="fas fa-star text-db-warning text-xs"></i>
                      ) : null}
                      <span className="text-sm font-medium text-db-text">{query.name}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteQueryMutation.mutate(query.id);
                      }}
                      className="text-db-text-muted hover:text-db-accent transition-colors"
                    >
                      <i className="fas fa-trash text-xs"></i>
                    </button>
                  </div>
                  {query.description && (
                    <p className="text-xs text-db-text-muted mb-2">{query.description}</p>
                  )}
                  <div className="text-xs text-db-text-muted mb-2">
                    {formatTimeAgo(query.createdAt)}
                  </div>
                  <div className="text-xs text-db-text font-mono bg-db-panel p-2 rounded border border-db-border">
                    {truncateQuery(query.query)}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-bookmark text-3xl text-db-text-muted mb-2"></i>
                <p className="text-db-text-muted">No saved queries</p>
                <p className="text-sm text-db-text-muted mt-1">Save your first query to get started</p>
              </div>
            )}
          </div>
        )}

        {activeTab === "templates" && (
          <div className="space-y-2">
            {templates?.map((template: any, index: number) => (
              <div
                key={index}
                className="bg-db-dark hover:bg-db-hover rounded border border-db-border transition-colors cursor-pointer p-3"
                onClick={() => onQuerySelect(template.query)}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-db-text">{template.name}</span>
                  <i className="fas fa-play text-xs text-db-text-muted"></i>
                </div>
                <p className="text-xs text-db-text-muted mb-2">{template.description}</p>
                <div className="text-xs text-db-text font-mono bg-db-panel p-2 rounded border border-db-border">
                  {truncateQuery(template.query)}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "history" && (
          <div className="space-y-2">
            {historyLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="animate-pulse bg-db-dark h-16 rounded border border-db-border"></div>
                ))}
              </div>
            ) : queryHistory && queryHistory.length > 0 ? (
              queryHistory.map((item) => (
                <div
                  key={item.id}
                  className="bg-db-dark hover:bg-db-hover rounded border border-db-border transition-colors cursor-pointer p-3"
                  onClick={() => onQuerySelect(item.query)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-2">
                      <i className={`fas ${item.success ? 'fa-check-circle text-db-success' : 'fa-exclamation-triangle text-db-accent'} text-xs`}></i>
                      <span className="text-sm font-medium text-db-text">
                        {item.success ? 'Successful Query' : 'Failed Query'}
                      </span>
                    </div>
                  </div>
                  <div className="text-xs text-db-text-muted mb-2">
                    {formatTimeAgo(item.executedAt)} • {item.executionTime}ms
                    {item.success && item.rowsReturned !== null && ` • ${item.rowsReturned} rows`}
                  </div>
                  {!item.success && item.errorMessage && (
                    <div className="text-xs text-db-accent mb-2">{item.errorMessage}</div>
                  )}
                  <div className="text-xs text-db-text font-mono bg-db-panel p-2 rounded border border-db-border">
                    {truncateQuery(item.query)}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-history text-3xl text-db-text-muted mb-2"></i>
                <p className="text-db-text-muted">No query history</p>
                <p className="text-sm text-db-text-muted mt-1">Execute queries to see history</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Save Query Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="bg-db-panel border-db-border">
          <DialogHeader>
            <DialogTitle className="text-db-text">Save Query</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-db-text mb-2">Query Name</label>
              <Input
                value={queryName}
                onChange={(e) => setQueryName(e.target.value)}
                placeholder="Enter a descriptive name..."
                className="bg-db-dark border-db-border text-db-text"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-db-text mb-2">Description (optional)</label>
              <Textarea
                value={queryDescription}
                onChange={(e) => setQueryDescription(e.target.value)}
                placeholder="Add a description for this query..."
                className="bg-db-dark border-db-border text-db-text h-20 resize-none"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="markFavorite"
                checked={markFavorite}
                onCheckedChange={(checked) => setMarkFavorite(checked as boolean)}
              />
              <label htmlFor="markFavorite" className="text-sm text-db-text">
                Mark as favorite
              </label>
            </div>
          </div>
          <div className="flex space-x-3 mt-6">
            <Button
              onClick={handleSaveQuery}
              disabled={saveQueryMutation.isPending}
              className="bg-db-accent hover:bg-red-600 text-white flex-1"
            >
              {saveQueryMutation.isPending ? "Saving..." : "Save Query"}
            </Button>
            <Button
              onClick={() => setShowSaveDialog(false)}
              variant="outline"
              className="border-db-border text-db-text hover:bg-db-hover"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
