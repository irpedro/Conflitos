import { useEffect, useRef } from "react";
import * as monaco from "monaco-editor";
import { configureMonaco } from "@/lib/monaco-config";

interface QueryEditorProps {
  value: string;
  onChange: (value: string) => void;
  onExecute: () => void;
}

export default function QueryEditor({ value, onChange, onExecute }: QueryEditorProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Configure Monaco
    configureMonaco();

    // Create editor
    const editor = monaco.editor.create(containerRef.current, {
      value,
      language: "sql",
      theme: "vs-dark",
      fontSize: 14,
      fontFamily: "'JetBrains Mono', 'Courier New', monospace",
      lineHeight: 1.5,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      automaticLayout: true,
      wordWrap: "on",
      contextmenu: true,
      selectOnLineNumbers: true,
      roundedSelection: false,
      readOnly: false,
      cursorStyle: "line",
      suggestOnTriggerCharacters: true,
      acceptSuggestionOnEnter: "on",
      tabCompletion: "on",
      wordBasedSuggestions: true,
    });

    editorRef.current = editor;

    // Handle value changes
    const onDidChangeModelContent = editor.onDidChangeModelContent(() => {
      onChange(editor.getValue());
    });

    // Add keyboard shortcuts
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      onExecute();
    });

    return () => {
      onDidChangeModelContent.dispose();
      editor.dispose();
    };
  }, []);

  useEffect(() => {
    if (editorRef.current && editorRef.current.getValue() !== value) {
      editorRef.current.setValue(value);
    }
  }, [value]);

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="bg-db-panel border-b border-db-border px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-sm font-medium text-db-text">Query Editor</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-db-success rounded-full"></div>
              <span className="text-xs text-db-text-muted">Ready</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <select className="bg-db-dark border border-db-border rounded px-2 py-1 text-sm text-db-text">
              <option value="postgresql">PostgreSQL</option>
            </select>
          </div>
        </div>
      </div>

      <div 
        ref={containerRef}
        className="flex-1 min-h-0 bg-db-dark"
        style={{ height: "100%" }}
      />

      <div className="bg-db-dark border-t border-db-border px-4 py-2">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <span className="text-db-text-muted">
              Press <kbd className="bg-db-border px-2 py-1 rounded text-xs">Ctrl+Enter</kbd> to execute
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-db-text-muted">PostgreSQL Mode</span>
          </div>
        </div>
      </div>
    </div>
  );
}
