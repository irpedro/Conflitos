import { useState } from "react";

interface SchemaTable {
  name: string;
  columns: Array<{
    name: string;
    type: string;
    nullable: boolean;
    default?: string;
  }>;
  rowCount: number;
}

interface SchemaBrowserProps {
  schema?: {
    tables: SchemaTable[];
  };
  isLoading: boolean;
  onTableSelect: (tableName: string) => void;
}

const tableCategories = {
  "Core Entities": ["conflito", "grupo_armado", "divisao", "org_mediadora"],
  "Leadership": ["lider_politico", "chefe_militar"],
  "Weapons & Trading": ["armas", "traficantes", "fornecimento", "contrabandeia"],
  "Conflict Classifications": ["religiao", "territorio", "economia", "raca", "paises_em_conflito"],
  "Participation": ["participacao_grupo_armado", "participacao_org_mediadora", "dialogo", "lideranca"],
  "System": ["saved_queries", "query_history"]
};

const tableIcons: Record<string, string> = {
  conflito: "fas fa-explosion text-db-accent",
  grupo_armado: "fas fa-users text-amber-500",
  divisao: "fas fa-shield-halved text-blue-500",
  org_mediadora: "fas fa-handshake text-db-success",
  lider_politico: "fas fa-crown text-purple-500",
  chefe_militar: "fas fa-star text-db-warning",
  armas: "fas fa-gun text-red-400",
  traficantes: "fas fa-user-secret text-gray-400",
  religiao: "fas fa-place-of-worship text-amber-400",
  territorio: "fas fa-map text-green-400",
  economia: "fas fa-coins text-yellow-400",
  raca: "fas fa-people-group text-orange-400",
  default: "fas fa-table text-db-text-muted"
};

export default function SchemaBrowser({ schema, isLoading, onTableSelect }: SchemaBrowserProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(["Core Entities", "Leadership"])
  );

  const toggleCategory = (category: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedCategories(newExpanded);
  };

  const filteredTables = schema?.tables.filter(table =>
    table.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const getCategoryTables = (category: string) => {
    const categoryTableNames = tableCategories[category as keyof typeof tableCategories] || [];
    return filteredTables.filter(table => categoryTableNames.includes(table.name));
  };

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-db-border">
          <h2 className="text-lg font-semibold text-db-text mb-3">Database Schema</h2>
          <div className="animate-pulse bg-db-dark h-10 rounded-lg"></div>
        </div>
        <div className="flex-1 p-4">
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="animate-pulse bg-db-dark h-12 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-db-border">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-db-text">ConflictDB Schema</h2>
          <button className="text-db-text-muted hover:text-db-text transition-colors">
            <i className="fas fa-sync-alt text-sm"></i>
          </button>
        </div>
        <div className="flex items-center space-x-2 text-sm text-db-text-muted mb-3">
          <i className="fas fa-database text-db-accent"></i>
          <span>PostgreSQL 14.2</span>
          <span className="w-2 h-2 bg-db-success rounded-full"></span>
        </div>
        <div className="relative">
          <input
            type="text"
            placeholder="Search tables..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-db-dark border border-db-border rounded-lg px-3 py-2 text-sm text-db-text placeholder-db-text-muted focus:border-db-accent focus:outline-none"
          />
          <i className="fas fa-search absolute right-3 top-2.5 text-db-text-muted"></i>
        </div>
      </div>

      {/* Schema Tree */}
      <div className="flex-1 overflow-y-auto p-2 scrollbar-thin">
        {Object.entries(tableCategories).map(([category, _]) => {
          const categoryTables = getCategoryTables(category);
          if (categoryTables.length === 0) return null;

          const isExpanded = expandedCategories.has(category);

          return (
            <div key={category} className="mb-4">
              <button
                onClick={() => toggleCategory(category)}
                className="flex items-center text-sm font-medium text-db-text-muted mb-2 px-2 w-full hover:text-db-text transition-colors"
              >
                <i className={`fas ${isExpanded ? 'fa-folder-open' : 'fa-folder'} text-xs mr-2`}></i>
                <span>{category} ({categoryTables.length})</span>
                <i className={`fas ${isExpanded ? 'fa-chevron-down' : 'fa-chevron-right'} text-xs ml-auto`}></i>
              </button>

              {isExpanded && (
                <div className="space-y-1">
                  {categoryTables.map((table) => (
                    <div
                      key={table.name}
                      className="group cursor-pointer"
                      onClick={() => onTableSelect(table.name)}
                    >
                      <div className="flex items-center justify-between px-3 py-2 rounded hover:bg-db-hover transition-colors">
                        <div className="flex items-center">
                          <i className={`${tableIcons[table.name] || tableIcons.default} text-xs mr-3`}></i>
                          <span className="text-sm text-db-text">{table.name}</span>
                        </div>
                        <span className="text-xs text-db-text-muted group-hover:text-db-text">
                          {table.columns.length} cols
                        </span>
                      </div>
                      <div className="text-xs text-db-text-muted ml-6 px-3 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {table.columns.slice(0, 3).map(col => col.name).join(", ")}
                        {table.columns.length > 3 && "..."}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {filteredTables.length === 0 && searchTerm && (
          <div className="text-center py-8">
            <i className="fas fa-search text-3xl text-db-text-muted mb-2"></i>
            <p className="text-db-text-muted">No tables found matching "{searchTerm}"</p>
          </div>
        )}
      </div>
    </div>
  );
}
