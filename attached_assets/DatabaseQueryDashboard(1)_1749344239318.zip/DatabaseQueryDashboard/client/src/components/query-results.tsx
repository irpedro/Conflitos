import { useState } from "react";

interface QueryResultsProps {
  results: any;
  isLoading: boolean;
}

export default function QueryResults({ results, isLoading }: QueryResultsProps) {
  const [showExportMenu, setShowExportMenu] = useState(false);

  const exportToCSV = () => {
    if (!results?.success || !results?.data?.length) return;

    const headers = Object.keys(results.data[0]);
    const csvContent = [
      headers.join(","),
      ...results.data.map((row: any) =>
        headers.map(header => `"${String(row[header] || "").replace(/"/g, '""')}"`).join(",")
      )
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `query_results_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    setShowExportMenu(false);
  };

  if (isLoading) {
    return (
      <div className="h-1/2 bg-db-panel border-t border-db-border flex flex-col">
        <div className="border-b border-db-border px-4 py-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-db-text">Query Results</h3>
            <div className="flex items-center space-x-2 text-xs text-db-text-muted">
              <i className="fas fa-spinner fa-spin"></i>
              <span>Executing query...</span>
            </div>
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <i className="fas fa-spinner fa-spin text-3xl text-db-text-muted mb-4"></i>
            <p className="text-db-text-muted">Executing query...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div className="h-1/2 bg-db-panel border-t border-db-border flex flex-col">
        <div className="border-b border-db-border px-4 py-2">
          <h3 className="text-sm font-medium text-db-text">Query Results</h3>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <i className="fas fa-play text-3xl text-db-text-muted mb-4"></i>
            <p className="text-db-text-muted">Execute a query to see results</p>
          </div>
        </div>
      </div>
    );
  }

  if (!results.success) {
    return (
      <div className="h-1/2 bg-db-panel border-t border-db-border flex flex-col">
        <div className="border-b border-db-border px-4 py-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-db-text">Query Results</h3>
            <div className="flex items-center space-x-2 text-xs text-red-400">
              <i className="fas fa-exclamation-triangle"></i>
              <span>Error</span>
            </div>
          </div>
        </div>
        <div className="flex-1 p-4">
          <div className="bg-red-900 border border-red-700 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <i className="fas fa-exclamation-triangle text-red-400"></i>
              <span className="font-medium text-red-400">Query Error</span>
            </div>
            <p className="text-red-300 text-sm font-mono">{results.error}</p>
          </div>
        </div>
      </div>
    );
  }

  const { data, rowCount, executionTime } = results;

  return (
    <div className="h-1/2 bg-db-panel border-t border-db-border flex flex-col">
      <div className="border-b border-db-border px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-sm font-medium text-db-text">Query Results</h3>
            <div className="flex items-center space-x-2 text-xs text-db-text-muted">
              <span>{rowCount} rows</span>
              <span>•</span>
              <span>{executionTime}ms</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="text-db-text-muted hover:text-db-text transition-colors"
            >
              <i className="fas fa-download text-sm"></i>
            </button>
            
            {showExportMenu && (
              <div className="absolute right-0 top-8 bg-db-dark border border-db-border rounded-lg shadow-lg z-10">
                <button
                  onClick={exportToCSV}
                  className="block w-full text-left px-4 py-2 text-sm text-db-text hover:bg-db-hover"
                >
                  <i className="fas fa-file-csv mr-2"></i>
                  Export as CSV
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {data && data.length > 0 ? (
          <table className="w-full">
            <thead className="bg-db-dark sticky top-0">
              <tr>
                {Object.keys(data[0]).map((header, index) => (
                  <th
                    key={header}
                    className={`px-4 py-3 text-left text-xs font-medium text-db-text-muted uppercase tracking-wider ${
                      index < Object.keys(data[0]).length - 1 ? 'border-r border-db-border' : ''
                    }`}
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-db-panel divide-y divide-db-border">
              {data.map((row: any, rowIndex: number) => (
                <tr key={rowIndex} className="hover:bg-db-hover transition-colors">
                  {Object.values(row).map((value: any, cellIndex: number) => (
                    <td
                      key={cellIndex}
                      className={`px-4 py-3 text-sm text-db-text ${
                        cellIndex < Object.values(row).length - 1 ? 'border-r border-db-border' : ''
                      }`}
                    >
                      {value !== null && value !== undefined ? String(value) : (
                        <span className="text-db-text-muted italic">NULL</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center">
              <i className="fas fa-table text-3xl text-db-text-muted mb-4"></i>
              <p className="text-db-text-muted">No results returned</p>
              <p className="text-sm text-db-text-muted mt-2">
                Query executed successfully but returned no rows
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
