import * as monaco from "monaco-editor";

export function configureMonaco() {
  // Define custom PostgreSQL SQL theme
  monaco.editor.defineTheme("postgresql-dark", {
    base: "vs-dark",
    inherit: true,
    rules: [
      { token: "keyword.sql", foreground: "f97316", fontStyle: "bold" },
      { token: "string.sql", foreground: "10b981" },
      { token: "number.sql", foreground: "3b82f6" },
      { token: "comment.sql", foreground: "6b7280", fontStyle: "italic" },
      { token: "identifier.sql", foreground: "f3f4f6" },
      { token: "operator.sql", foreground: "f59e0b" },
      { token: "delimiter.sql", foreground: "d1d5db" },
    ],
    colors: {
      "editor.background": "#1a1a1a",
      "editor.foreground": "#f3f4f6",
      "editor.lineHighlightBackground": "#262626",
      "editor.selectionBackground": "#374151",
      "editor.inactiveSelectionBackground": "#1f2937",
      "editorCursor.foreground": "#dc2626",
      "editorLineNumber.foreground": "#6b7280",
      "editorLineNumber.activeForeground": "#9ca3af",
    },
  });

  // Set PostgreSQL SQL language configuration
  monaco.languages.setLanguageConfiguration("sql", {
    comments: {
      lineComment: "--",
      blockComment: ["/*", "*/"],
    },
    brackets: [
      ["{", "}"],
      ["[", "]"],
      ["(", ")"],
    ],
    autoClosingPairs: [
      { open: "{", close: "}" },
      { open: "[", close: "]" },
      { open: "(", close: ")" },
      { open: "'", close: "'", notIn: ["string", "comment"] },
      { open: '"', close: '"', notIn: ["string"] },
    ],
    surroundingPairs: [
      { open: "{", close: "}" },
      { open: "[", close: "]" },
      { open: "(", close: ")" },
      { open: "'", close: "'" },
      { open: '"', close: '"' },
    ],
  });

  // Enhanced PostgreSQL keywords and functions
  monaco.languages.setMonarchTokensProvider("sql", {
    defaultToken: "invalid",
    tokenPostfix: ".sql",
    ignoreCase: true,

    keywords: [
      "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER",
      "TABLE", "INDEX", "VIEW", "PROCEDURE", "FUNCTION", "TRIGGER", "DATABASE", "SCHEMA",
      "AND", "OR", "NOT", "IN", "EXISTS", "BETWEEN", "LIKE", "ILIKE", "IS", "NULL",
      "JOIN", "INNER", "LEFT", "RIGHT", "FULL", "OUTER", "CROSS", "ON", "USING",
      "GROUP", "BY", "ORDER", "HAVING", "LIMIT", "OFFSET", "DISTINCT", "ALL", "ANY", "SOME",
      "UNION", "INTERSECT", "EXCEPT", "WITH", "RECURSIVE", "AS", "CASE", "WHEN", "THEN", "ELSE", "END",
      "IF", "ELSIF", "WHILE", "FOR", "LOOP", "CONTINUE", "EXIT", "RETURN", "DECLARE", "BEGIN",
      "COMMIT", "ROLLBACK", "SAVEPOINT", "TRANSACTION", "ISOLATION", "LEVEL", "READ", "WRITE",
      "SERIAL", "BIGSERIAL", "INTEGER", "BIGINT", "SMALLINT", "DECIMAL", "NUMERIC", "REAL", "DOUBLE",
      "VARCHAR", "CHAR", "TEXT", "BOOLEAN", "DATE", "TIME", "TIMESTAMP", "INTERVAL", "UUID", "JSON", "JSONB",
      "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "UNIQUE", "CHECK", "DEFAULT", "CONSTRAINT",
      "GRANT", "REVOKE", "ROLE", "USER", "PRIVILEGES", "SUPERUSER", "CREATEDB", "CREATEROLE",
      "EXPLAIN", "ANALYZE", "VACUUM", "REINDEX", "CLUSTER", "COPY", "TRUNCATE"
    ],

    operators: [
      "=", ">", "<", "!", "~", "?", ":", "==", "<=", ">=", "!=", "<>",
      "&&", "||", "++", "--", "+", "-", "*", "/", "&", "|", "^", "%", "<<",
      ">>", ">>>", "+=", "-=", "*=", "/=", "&=", "|=", "^=", "%=", "<<=", ">>=", ">>>="
    ],

    builtinFunctions: [
      "COUNT", "SUM", "AVG", "MIN", "MAX", "STDDEV", "VARIANCE", "STRING_AGG",
      "CONCAT", "LENGTH", "SUBSTR", "SUBSTRING", "UPPER", "LOWER", "TRIM", "LTRIM", "RTRIM",
      "ROUND", "CEIL", "FLOOR", "ABS", "SQRT", "POWER", "MOD", "RANDOM",
      "NOW", "CURRENT_TIMESTAMP", "CURRENT_DATE", "CURRENT_TIME", "EXTRACT", "DATE_PART",
      "ARRAY_AGG", "JSON_AGG", "JSON_OBJECT_AGG", "ROW_NUMBER", "RANK", "DENSE_RANK",
      "LAG", "LEAD", "FIRST_VALUE", "LAST_VALUE", "COALESCE", "NULLIF", "GREATEST", "LEAST"
    ],

    tokenizer: {
      root: [
        { include: "@comments" },
        { include: "@whitespace" },
        { include: "@numbers" },
        { include: "@strings" },
        { include: "@complexIdentifiers" },
        [/[;,.]/, "delimiter"],
        [/[()]/, "@brackets"],
        [
          /[\w@#$]+/,
          {
            cases: {
              "@keywords": "keyword",
              "@builtinFunctions": "predefined",
              "@default": "identifier"
            }
          }
        ],
        [/[<>=!%&+\-*/|~^]/, "operator"]
      ],

      whitespace: [[/\s+/, "white"]],

      comments: [
        [/--+.*/, "comment"],
        [/\/\*/, { token: "comment.quote", next: "@comment" }]
      ],

      comment: [
        [/[^*/]+/, "comment"],
        [/\*\//, { token: "comment.quote", next: "@pop" }],
        [/./, "comment"]
      ],

      numbers: [
        [/0[xX][0-9a-fA-F]*/, "number"],
        [/[$][+-]*\d*(\.\d*)?/, "number"],
        [/((\d+(\.\d*)?)|(\.\d+))([eE][\-+]?\d+)?/, "number"]
      ],

      strings: [
        [/N?'/, { token: "string", next: "@string" }],
        [/N?"/, { token: "string.double", next: "@stringDouble" }]
      ],

      string: [
        [/[^']+/, "string"],
        [/''/, "string"],
        [/'/, { token: "string", next: "@pop" }]
      ],

      stringDouble: [
        [/[^"]+/, "string.double"],
        [/""/, "string.double"],
        [/"/, { token: "string.double", next: "@pop" }]
      ],

      complexIdentifiers: [
        [/\[/, { token: "identifier.quote", next: "@bracketedIdentifier" }],
        [/"/, { token: "identifier.quote", next: "@quotedIdentifier" }]
      ],

      bracketedIdentifier: [
        [/[^\]]+/, "identifier"],
        [/]]/, "identifier"],
        [/]/, { token: "identifier.quote", next: "@pop" }]
      ],

      quotedIdentifier: [
        [/[^"]+/, "identifier"],
        [/""/, "identifier"],
        [/"/, { token: "identifier.quote", next: "@pop" }]
      ]
    }
  });

  // Add completion provider for PostgreSQL
  monaco.languages.registerCompletionItemProvider("sql", {
    provideCompletionItems: (model, position) => {
      const suggestions = [
        // Conflict database specific tables
        ...["conflito", "grupo_armado", "divisao", "org_mediadora", "lider_politico", "chefe_militar",
          "armas", "traficantes", "religiao", "territorio", "economia", "raca", "paises_em_conflito",
          "participacao_grupo_armado", "participacao_org_mediadora", "dialogo", "lideranca",
          "fornecimento", "contrabandeia"].map(table => ({
          label: table,
          kind: monaco.languages.CompletionItemKind.Module,
          insertText: table,
          detail: "Table"
        })),
        
        // Common column names from the schema
        ...["id", "nome", "total_mortos", "total_feridos", "causa", "lugar", "numero_baixas",
          "numero_divisao", "id_grupo_armado", "numero_barcos", "numero_tanques", "numero_avioes",
          "numero_homens", "faixa_hierarquica", "capacidade_destrutiva", "apoio"].map(column => ({
          label: column,
          kind: monaco.languages.CompletionItemKind.Field,
          insertText: column,
          detail: "Column"
        })),
        
        // SQL keywords
        ...["SELECT", "FROM", "WHERE", "JOIN", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN",
          "GROUP BY", "ORDER BY", "HAVING", "LIMIT", "OFFSET", "UNION", "INSERT", "UPDATE",
          "DELETE", "CREATE", "ALTER", "DROP"].map(keyword => ({
          label: keyword,
          kind: monaco.languages.CompletionItemKind.Keyword,
          insertText: keyword,
          detail: "SQL Keyword"
        }))
      ];

      return { suggestions };
    }
  });
}
